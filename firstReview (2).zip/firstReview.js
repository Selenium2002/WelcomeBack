const apiKey = "a7af953e4c39bb41b37ec5bcafedde33";

const apiUrl ="https://api.openweathermap.org/data/2.5/weather?units=matric&q=egypt"

async function checkWeather(){
    const response = await fetch(apiUrl + '&appid=${apiKey');
    var data = await response.json();
    console.log(data);
}
