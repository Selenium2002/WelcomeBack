function generateYears(start, end) {

    var years;
       
    document.write("<select>")

    for (years =start; years <= end; years++){

        document.write("<option value='" + years + "'>" + years + "</option>")
    }

    document.write("</select>")
}

generateYears(1950, 2010)