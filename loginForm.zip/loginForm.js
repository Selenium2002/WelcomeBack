var signupBtn = document.getElementById("signupBtn"),

    signinBtn = document.getElementById("signinBtn"),

    nameField = document.getElementBiId("nameField"),

    title = document.getElementById("title");

signinBtn.onclick = function() {
    nameField.style.maxHeight = "0";
    title.innerHTML = "sign In";
    signupBtn.classList.add("disable");
    signinBtn.classList.remove("disable");
} 

signupBtn.onclick = function() {
    nameField.style.maxHeight = "60px";
    title.innerHTML = "sign up";
    signupBtn.classList.remove("disable");
    signinBtn.classList.add("disable");
} 